TPM Manager - Secure Recovery Key Manager

Instructions:
1. Double-click Launch_TPM_Manager.bat
2. Choose a location for your recovery files (first time only)
3. Manage encryption/decryption of your keys safely.

Requires Windows with PowerShell.
